

class MNI152:
    """
    Helper class for the MNI152 standard brain atlas.
    """
    pass