def plusplus(a, b):

    return a + b