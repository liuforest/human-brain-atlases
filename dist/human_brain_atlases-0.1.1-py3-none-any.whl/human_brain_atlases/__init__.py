from human_brain_atlases.atlases import Schaefer

__version__ = "0.1.0"