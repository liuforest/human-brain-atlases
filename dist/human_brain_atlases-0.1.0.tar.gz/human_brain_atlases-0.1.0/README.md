# human-brain-atlases
 Human brain atlas parcellations based on the MNI152 template

## Usage

```python
from human_brain_atlases import plusplus

result = plusplus(1, 2) # returns 3 -- for testing